# CreativeTales by Raashida

A responsive static portfolio website for GitHub Pages.

## Publish
1. Upload all files and folders in this package to the root of the repository `rash32542-beep.github.io`.
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then Save.
5. Wait a few minutes and visit https://rash32542-beep.github.io/.

## Update the gallery
The featured artwork card currently links to the supplied Instagram post. Replace its CSS-designed placeholder with your own artwork image when you have the image file. Update the image in `index.html` and keep the Instagram link.

## Google Search
After the site is live, add the URL to Google Search Console and submit `https://rash32542-beep.github.io/sitemap.xml`. Indexing is not instant or guaranteed.
